--[[
gamemodes/darkrp/entities/weapons/gmod_tool/stools/stacker.lua
--]]
local bit = bit
local util = util
local math = math
local undo = undo
local halo = halo
local game = game
local ents = ents
local pairs = pairs 
local table = table
local Angle = Angle
local Color = Color
local Vector = Vector
local IsValid = IsValid
local language = language
local tonumber = tonumber
local constraint = constraint
local concommand = concommand
local LocalPlayer = LocalPlayer
local CreateConVar = CreateConVar
local GetConVarNumber = GetConVarNumber
local RunConsoleCommand = RunConsoleCommand

local MOVETYPE_NONE = MOVETYPE_NONE
local SOLID_VPHYSICS = SOLID_VPHYSICS
local RENDERMODE_TRANSALPHA = RENDERMODE_TRANSALPHA

--[[--------------------------------------------------------------------------
-- Tool Settings
--------------------------------------------------------------------------]]--

TOOL.Category   = "Construction"
TOOL.Name       = "#Tool.stacker.name"
TOOL.Command    = nil
TOOL.ConfigName = ""

TOOL.ClientConVar[ "dir" ]       = "1"
TOOL.ClientConVar[ "material" ]  = "1"
TOOL.ClientConVar[ "model" ]     = ""
TOOL.ClientConVar[ "offsetx" ]   = "0"
TOOL.ClientConVar[ "offsety" ]   = "0"
TOOL.ClientConVar[ "offsetz" ]   = "0"
TOOL.ClientConVar[ "rotp" ]      = "0"
TOOL.ClientConVar[ "roty" ]      = "0"
TOOL.ClientConVar[ "rotr" ]      = "0"

if ( CLIENT ) then

	language.Add( "Tool.stacker.name", "Stacker" )
	language.Add( "Tool.stacker.desc", "Allows you to easily stack props" )
	language.Add( "Tool.stacker.0",    "Click to stack the prop you're pointing at." )
	language.Add( "Undone_stacker",    "Undone stacked prop(s)" )
	
end

--[[--------------------------------------------------------------------------
-- Enumerations
--------------------------------------------------------------------------]]--

local DIRECTION_UP     = 1
local DIRECTION_DOWN   = 2
local DIRECTION_FRONT  = 3
local DIRECTION_BEHIND = 4
local DIRECTION_RIGHT  = 5
local DIRECTION_LEFT   = 6

local VECTOR_ZERO = Vector( 0, 0, 0 )

local ANGLE_ZERO = Angle( 0, 0, 0 )
local ANGLE_FRONT      = ANGLE_ZERO:Forward()
local ANGLE_RIGHT      = ANGLE_ZERO:Right()
local ANGLE_UP         = ANGLE_ZERO:Up()
local ANGLE_BEHIND     = -ANGLE_FRONT
local ANGLE_LEFT       = -ANGLE_RIGHT
local ANGLE_DOWN       = -ANGLE_UP

local TRANSPARENT = Color( 255, 255, 255, 150 )

--[[--------------------------------------------------------------------------
-- Console Variables
--------------------------------------------------------------------------]]--

CreateConVar( "stacker_max_offsetx",     500, bit.bor( FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE ) ) -- defines the max distance on the x plane that stacked props can be offset (for individual control)
CreateConVar( "stacker_max_offsety",     500, bit.bor( FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE ) ) -- defines the max distance on the y plane that stacked props can be offset (for individual control)
CreateConVar( "stacker_max_offsetz",     500, bit.bor( FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE ) ) -- defines the max distance on the z plane that stacked props can be offset (for individual control)
CreateConVar( "stacker_stayinworld",       0, bit.bor( FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE ) ) -- determines whether props should be restricted to spawning inside the world or not (addresses possible crashes)
CreateConVar( "stacker_delay",             0, bit.bor( FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE ) ) -- determines the amount of time that must pass before a player can use stacker again
--------------------------------------------------------------------]]--

if ( CLIENT ) then
	local function ResetOffsets( ply, command, arguments )
		LocalPlayer():ConCommand( "stacker_offsetx 0" )
		LocalPlayer():ConCommand( "stacker_offsety 0" )
		LocalPlayer():ConCommand( "stacker_offsetz 0" )
		LocalPlayer():ConCommand( "stacker_rotp 0" )
		LocalPlayer():ConCommand( "stacker_roty 0" )
		LocalPlayer():ConCommand( "stacker_rotr 0" )
	end
	concommand.Add( "stacker_resetoffsets", ResetOffsets )
end


--[[--------------------------------------------------------------------------
-- 	GetGhostStack(), SetGhostStack( table )
--
--	Gets and sets the table of ghosted props in the stack.
--]]--
local function GetGhostStack() return GhostStack       end
local function SetGhostStack( tbl )   GhostStack = tbl end

--[[--------------------------------------------------------------------------
-- 	TOOL:GetDirection()
--
--	Gets the direction to stack the props
--]]--
function TOOL:GetDirection() return self:GetClientNumber( "dir" ) end

--[[--------------------------------------------------------------------------
-- 	TOOL:GetOffsetX(), TOOL:GetOffsetY(), TOOL:GetOffsetZ(), TOOL:GetOffsetVector()
--
--	Gets the distance to offset the position of the stacked props.
--	These values are clamped to prevent server crashes from players
--	using very high offset values.
--]]--
function TOOL:GetOffsetX() return math.Clamp( self:GetClientNumber( "offsetx" ), - GetConVarNumber( "stacker_max_offsetx" ), GetConVarNumber( "stacker_max_offsetx" ) ) end
function TOOL:GetOffsetY() return math.Clamp( self:GetClientNumber( "offsety" ), - GetConVarNumber( "stacker_max_offsety" ), GetConVarNumber( "stacker_max_offsety" ) ) end
function TOOL:GetOffsetZ() return math.Clamp( self:GetClientNumber( "offsetz" ), - GetConVarNumber( "stacker_max_offsetz" ), GetConVarNumber( "stacker_max_offsetz" ) ) end

function TOOL:GetOffsetVector() return Vector( self:GetOffsetX(), self:GetOffsetY(), self:GetOffsetZ() ) end

--[[--------------------------------------------------------------------------
-- 	TOOL:GetRotateP(), TOOL:GetRotateY(), TOOL:GetRotateR(), TOOL:GetRotateAngle()
--
--	Gets the value to rotate the angle of the stacked props.
--	These values are clamped to prevent server crashes from players
--	using very high rotation values.
--]]--
function TOOL:GetRotateP() return math.Clamp( self:GetClientNumber( "rotp" ), -360, 360 ) end
function TOOL:GetRotateY() return math.Clamp( self:GetClientNumber( "roty" ), -360, 360 ) end
function TOOL:GetRotateR() return math.Clamp( self:GetClientNumber( "rotr" ), -360, 360 ) end

function TOOL:GetRotateAngle() return Angle( self:GetRotateP(), self:GetRotateY(), self:GetRotateR() ) end

--[[--------------------------------------------------------------------------
-- 	TOOL:GetDelay()
--
--	Returns the time in seconds that must pass before a player can use stacker again.
--	For example, if stacker_delay is set to 3, a player must wait 3 seconds in between each
--	use of stacker's left click.
--]]--
function TOOL:GetDelay() return GetConVarNumber( "stacker_delay" ) end

--[[--------------------------------------------------------------------------
-- Tool Functions
--------------------------------------------------------------------------]]--

--[[--------------------------------------------------------------------------
--
-- 	 TOOL:Deploy()
--
--	Called when the player brings out this tool.
--]]--
function TOOL:Deploy()
	self:ReleaseGhostStack()
end

--[[--------------------------------------------------------------------------
--
-- 	 TOOL:Holster()
--
--	Called when the player switches to a different tool.
--]]--
function TOOL:Holster()
	self:ReleaseGhostStack()
end

--[[--------------------------------------------------------------------------
--
-- 	 TOOL:OnRemove()
--
--	Should be called when the toolgun is somehow removed, but more than likely
--	doesn't get called due to the way the gmod_tool was coded.
--]]--
function TOOL:OnRemove()
	self:ReleaseGhostStack()
end

--[[--------------------------------------------------------------------------
--
-- 	 TOOL:OnDrop()
--
--	Should be called when when the toolgun is dropped, but more than likely
--	doesn't get called due to the way to gmod_tool was coded.
--]]--
function TOOL:OnDrop()
	self:ReleaseGhostStack()
end

--	Attempts to create a stack of props relative to the entity being left clicked.
--]]--
function TOOL:LeftClick( trace )
	if ( !IsValid( trace.Entity ) or trace.Entity:GetClass() ~= "prop_physics" ) then return false end
	if ( CLIENT ) then return true end

	local count = 1
	
	if ( self:GetOwner().LastStackTime and self:GetOwner().LastStackTime + self:GetDelay() > CurTime() ) then self:GetOwner():PrintMessage( HUD_PRINTTALK, "You are using stacker too quickly" ) return false end
	self:GetOwner().LastStackTime = CurTime()
	
	local dir    = self:GetDirection()
	local offset = self:GetOffsetVector()
	local rotate = self:GetRotateAngle()

	local stayInWorld   = GetConVarNumber( "stacker_stayinworld" ) == 1

	local ply = self:GetOwner()
	local ent = trace.Entity

	local entPos  = ent:GetPos()
	local entAng  = ent:GetAngles()
	local entMod  = ent:GetModel()
	local entSkin = ent:GetSkin()
	local entMat  = ent:GetMaterial()
	local entCol  = ent:GetColor()
	
	local physMat  = ent:GetPhysicsObject():GetMaterial()
	local physGrav = ent:GetPhysicsObject():IsGravityEnabled()
	local lastEnt  = ent
	local newEnts  = { ent }
	local newEnt
	
	undo.Create( "stacker" )
	
	for i = 1, count, 1 do
		if ( !self:GetSWEP():CheckLimit( "props" ) )                           then break end
		if ( hook.Call( "PlayerSpawnProp", GAMEMODE, self:GetOwner(), entMod ) == false ) then break end
		
		stackdir, height = self:StackerCalcPos( lastEnt, dir, offset )
		
		entPos = entPos + stackdir * height + offset
		entAng = entAng + rotate
		
		if ( stayInWorld and !util.IsInWorld( entPos ) ) then ply:PrintMessage( HUD_PRINTTALK, "Stacked props must be spawned within the world" ) break end
		
		newEnt = ents.Create( "prop_physics" )
		newEnt:SetModel( entMod )
		newEnt:SetPos( entPos )
		newEnt:SetAngles( entAng )
		newEnt:SetSkin( entSkin )
		newEnt:Spawn()
		
		-- this hook is for external prop protections and anti-spam addons
		-- it is called before undo, ply:AddCount, and ply:AddCleanup to allow developers to
		-- remove or mark this entity so that those same functions (if overridden) can
		-- detect that the entity came from Stacker
		if ( !IsValid( newEnt ) or hook.Run( "StackerEntity", newEnt, self:GetOwner() ) ~= nil )             then continue end
		if ( !IsValid( newEnt ) or hook.Run( "PlayerSpawnedProp", self:GetOwner(), entMod, newEnt ) ~= nil ) then continue end
		
		lastEnt = newEnt
		table.insert( newEnts, newEnt )
		
		undo.AddEntity( newEnt )
		ply:AddCleanup( "props", newEnt )
	end
	newEnts = nil
	
	undo.SetPlayer( ply )
	undo.Finish()

	return true
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL:StackerCalcPos( entity, number, number, number )
--
--	Calculates the positions and angles of the entity being created in the stack.
--	This function uses a lookup table for added optimization as opposed to an if-else block.
--]]--
local CALC_POS = {
	[DIRECTION_UP]     = function( hi, low ) return ANGLE_UP,     math.abs( hi.z - low.z ) end,
	[DIRECTION_DOWN]   = function( hi, low ) return ANGLE_DOWN,   math.abs( hi.z - low.z ) end,
	[DIRECTION_FRONT]  = function( hi, low ) return ANGLE_FRONT,  math.abs( hi.x - low.x ) end,
	[DIRECTION_BEHIND] = function( hi, low ) return ANGLE_BEHIND, math.abs( hi.x - low.x ) end,
	[DIRECTION_RIGHT]  = function( hi, low ) return ANGLE_RIGHT,  math.abs( hi.y - low.y ) end,
	[DIRECTION_LEFT]   = function( hi, low ) return ANGLE_LEFT,   math.abs( hi.y - low.y ) end,
}

function TOOL:StackerCalcPos( ent, dir, offset )
	local height, direction
	
	direction, height = CALC_POS[ dir ]( ent:WorldSpaceAABB() )
	
	return direction, height, offset
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL:CreateGhostStack( entity, vector, angle )
--
--	Attempts to create a stack of ghosted props on the prop the player is currently
--	looking at before they actually left click to create the stack. This acts
--	as a visual aid for the player so they can see the results without actually creating
--	the entities yet (if in multiplayer).
--]]--
function TOOL:CreateGhostStack( ent )
	if ( GetGhostStack() ) then self:ReleaseGhostStack() end

	local entMod  = ent:GetModel()
	local entSkin = ent:GetSkin()
	
	local ghost
	
	if ( CLIENT ) then ghost = ents.CreateClientProp( entMod )
	else               ghost = ents.Create( "prop_physics" ) end
	
	ghost:SetModel( entMod )
	ghost:SetSkin( entSkin )
	ghost:Spawn()

	ghost:SetSolid( SOLID_VPHYSICS )
	ghost:SetMoveType( MOVETYPE_NONE )
	ghost:SetRenderMode( RENDERMODE_TRANSALPHA )
	ghost:SetNotSolid( true )
	
	SetGhostStack( ghost )
	
	return true
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL:ReleaseGhostStack()
--	
--	Attempts to remove all ghosted props in the stack. 
--	This occurs when the player stops looking at a prop with the stacker tool equipped.
--]]--
function TOOL:ReleaseGhostStack()
	local gh = GetGhostStack()
	if !IsValid(gh) then return end
	gh:Remove()
	
	SetGhostStack( nil )
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL:CheckGhostStack()
--
--	Attempts to validate the status of the ghosted props in the stack.
--]]--
function TOOL:CheckGhostStack()
	return IsValid(GetGhostStack())
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL:UpdateGhostStack( entity )
--
--	Attempts to update the positions and angles of all ghosted props in the stack.
--]]--
function TOOL:UpdateGhostStack( ent )
	local dir    = self:GetDirection()
	local offset = self:GetOffsetVector()
	local rotate = self:GetRotateAngle()
	
	local lastEnt = ent
	local entPos = lastEnt:GetPos()
	local entAng = lastEnt:GetAngles()
	
	local stackdir, height = self:StackerCalcPos( lastEnt, dir, offset )
	local ghost

	entPos = entPos + stackdir * height + offset
	entAng = entAng + rotate

	local ghost = GetGhostStack()
	
	ghost:SetAngles(entAng)
	ghost:SetPos(entPos)
	ghost:SetMaterial("")
	ghost:SetColor(TRANSPARENT)
	ghost:SetNoDraw(false)
	lastEnt = ghost
end

--[[--------------------------------------------------------------------------
--
--	TOOL:Think()
--
--	While the stacker tool is equipped, this function will check to see if
--	the player is looking at any props and attempt to create the stack of
--	ghosted props before the players actually left clicks.
--]]--
function TOOL:Think()
	if ( SERVER ) then return end
	
	local ply = self:GetOwner()
	local ent = ply:GetEyeTrace().Entity
	
	if ( IsValid( ent ) and ent:GetClass() == "prop_physics" ) then
		self.CurrentEnt = ent

		if ( self.CurrentEnt == self.LastEnt ) then
			if ( self:CheckGhostStack() ) then
				self:UpdateGhostStack( self.CurrentEnt )
			else
				self:ReleaseGhostStack()
				self.LastEnt = nil
				return
			end
		else
			if ( self:CreateGhostStack( self.CurrentEnt ) ) then
				self.LastEnt = self.CurrentEnt 
			end
		end

		if !GetGhostStack() then return end
	else
		self:ReleaseGhostStack()
		self.LastEnt = nil
	end
end

--[[--------------------------------------------------------------------------
--
-- 	TOOL.BuildCPanel( panel )
--
--	Builds the control panel menu that can be seen when holding Q and accessing
--	the stacker menu.
--]]--
function TOOL.BuildCPanel( cpanel )
	cpanel:AddControl( "Header", { Text = "#Tool.stacker.name", Description	= "#Tool.stacker.desc" } )

	local params = { Label = "Направление", MenuButton = "0", Options = {} }
	params.Options[ "Up" ]     = { stacker_dir = DIRECTION_UP }
	params.Options[ "Down" ]   = { stacker_dir = DIRECTION_DOWN }
	params.Options[ "Front" ]  = { stacker_dir = DIRECTION_FRONT }
	params.Options[ "Behind" ] = { stacker_dir = DIRECTION_BEHIND }
	params.Options[ "Right" ]  = { stacker_dir = DIRECTION_RIGHT }
	params.Options[ "Left" ]   = { stacker_dir = DIRECTION_LEFT }
	cpanel:AddControl( "ComboBox", params )
	
	--cpanel:AddControl( "Header", { Text = "Advanced Options", Description = "These options are for advanced users. Leave them all default ( 0 ) if you don't understand what they do." }  )
	cpanel:AddControl( "Button", { Label = "Сброс", Command = "stacker_resetoffsets", Text = "Reset" } )
	
	cpanel:AddControl( "Slider", { Label = "Смещение X ( вперёд/назад )", Type = "Float", Min = - GetConVarNumber( "stacker_max_offsetx" ), Max = GetConVarNumber( "stacker_max_offsetx" ), Value = 0, Command = "stacker_offsetx" } )
	cpanel:AddControl( "Slider", { Label = "Смещение Y ( вправо/влево )",   Type = "Float", Min = - GetConVarNumber( "stacker_max_offsety" ), Max = GetConVarNumber( "stacker_max_offsety" ), Value = 0, Command = "stacker_offsety" } )
	cpanel:AddControl( "Slider", { Label = "Смещение Z ( вверх/вниз )",      Type = "Float", Min = - GetConVarNumber( "stacker_max_offsetz" ), Max = GetConVarNumber( "stacker_max_offsetz" ), Value = 0, Command = "stacker_offsetz" } )
	cpanel:AddControl( "Slider", { Label = "Подача поворота",              Type = "Float", Min = -360,  Max = 360,  Value = 0, Command = "stacker_rotp" } )
	cpanel:AddControl( "Slider", { Label = "Рыскание поворота",                Type = "Float", Min = -360,  Max = 360,  Value = 0, Command = "stacker_roty" } )
	cpanel:AddControl( "Slider", { Label = "Рулон поворота",               Type = "Float", Min = -360,  Max = 360,  Value = 0, Command = "stacker_rotr" } )
end

