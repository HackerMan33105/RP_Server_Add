nlr = { }
AddCSLuaFile()
nlr.include_sv = function(path)
  if SERVER then
    return include(path)
  end
end
nlr.include_cl = function(path)
  if CLIENT then
    return include(path)
  else
    return AddCSLuaFile(path)
  end
end
nlr.include_sh = function(path)
  nlr.include_sv(path)
  return nlr.include_cl(path)
end
return nlr.include_sh('nlr/main_sh.lua')
