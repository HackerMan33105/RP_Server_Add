nlr.cfg = {}

nlr.cfg.zone_radius = 400

nlr.cfg.fade_distance = 1000 

nlr.cfg.spawn_bufferdist = nlr.cfg.zone_radius * 1.5 

nlr.cfg.jail_bufferdist = 100 

nlr.cfg.punish_delay = 10 

nlr.cfg.zone_cooldown = 120 

nlr.cfg.revenge_cooldown = 40 

nlr.cfg.col_chat_red = Color(200, 0, 0)

nlr.cfg.strip_weapons_in_zone = true 

nlr.cfg.ignore_suicides = false

nlr.cfg.ignore_arrested_players = false

nlr.cfg.prevent_spawning_in_zone = true

nlr.cfg.punishment = {'notify_all_players', 'slay', 'log'}

nlr.cfg.zone_fillColor_default = Color(255,255,0,30) 

nlr.cfg.zone_fillColor_violated = Color(255,50,0,80) 

nlr.cfg.zone_outlineColor_default = Color(255,0,0,220)

local admin_groups = {
	['superadmin'] 	= true,
	['Trusted'] 		= true,
	['admin'] 		= true,
	['Helper+'] 		= true,
	['Helper'] 		= true,
	['Curator'] 		= true,
	['DSAdmin'] 		= true,
	['DAdmin'] 		= true,
	['DModerator'] 		= true
}

local ignored_groups = {
	['superadmin'] = true,
}

nlr.isAdmin = function(pl)
	return pl:IsAdmin() or admin_groups[pl:GetNWString('UserGroup') or '']
end

nlr.shouldIgnore = function(pl)
	local should = hook.Call('NLRShouldIgnore', nil, pl)
	return should == true or ignored_groups[pl:GetNWString('UserGroup') or ''] or false
end

nlr.cfg.tell_admins_on_enter = false

nlr.cfg.tell_admins_on_exit = false

nlr.cfg.admins_can_see_zones = true

nlr.cfg.plogs_support = false
