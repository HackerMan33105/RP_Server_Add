local pi, cos, sin, floor, ceil, sqrt
do
  local _obj_0 = math
  pi, cos, sin, floor, ceil, sqrt = _obj_0.pi, _obj_0.cos, _obj_0.sin, _obj_0.floor, _obj_0.ceil, _obj_0.sqrt
end
local Color, draw, render
do
  local _obj_0 = _G
  Color, draw, render = _obj_0.Color, _obj_0.draw, _obj_0.render
end
local mesh_Begin, mesh_End, mesh_Color, mesh_Position, mesh_Normal, mesh_AdvanceVertex
do
  local _obj_0 = mesh
  mesh_Begin, mesh_End, mesh_Color, mesh_Position, mesh_Normal, mesh_AdvanceVertex = _obj_0.Begin, _obj_0.End, _obj_0.Color, _obj_0.Position, _obj_0.Normal, _obj_0.AdvanceVertex
end
nlr.meshMaterial = CreateMaterial(nlr.uid(), "UnlitGeneric", {
  ["$basetexture"] = "color/white",
  ["$vertexalpha"] = 1,
  ["$vertexcolor"] = 1,
  ["$nocull"] = 1,
  ["$ignorez"] = 1
})
surface.CreateFont("nlr_warning_font-screen", {
  font = "Arial",
  size = ScreenScale(10),
  weight = 500
})
surface.CreateFont("nlr_warning_font", {
  font = "Arial",
  size = 50,
  weight = 5000
})
surface.CreateFont("nlr_warning_font-outlined", {
  font = "Arial",
  size = 50,
  weight = 5000,
  outline = true
})
nlr.drawCircle3d_filled = function(r2, segCount, col)
  local normal_up = Vector(0, 0, 2)
  local r = col.r
  local g = col.g
  local b = col.b
  local a = col.a
  local wedge_radians = pi * 2 / segCount
  local a0sin = sin(0)
  local a0cos = cos(0)
  local ang
  local a1cos, a1sin
  local p00x, p00y, p11x, p11y, p10x, p10y
  mesh_Begin(MATERIAL_TRIANGLES, segCount * 2 + 2)
  for i = 1, segCount do
    ang = i * wedge_radians
    a1cos = cos(ang)
    a1sin = sin(ang)
    p00x = 0
    p00y = 0
    local p01x = a0cos * r2
    local p01y = a0sin * r2
    p11x = 0
    p11y = 0
    p10x = a1cos * r2
    p10y = a1sin * r2
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p10x, p10y, 0))
    mesh_AdvanceVertex()
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p01x, p01y, 0))
    mesh_AdvanceVertex()
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p00x, p00y, 0))
    mesh_AdvanceVertex()
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p00x, p00y, 0))
    mesh_AdvanceVertex()
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p11x, p11y, 0))
    mesh_AdvanceVertex()
    mesh_Color(r, g, b, a)
    mesh_Normal(normal_up)
    mesh_Position(Vector(p10x, p10y, 0))
    mesh_AdvanceVertex()
    a0sin = a1sin
    a0cos = a1cos
  end
  return mesh_End()
end
nlr.drawCircle3d = function(r1, r2, segCount, gap_modNo, col)
  local normal_up = Vector(0, 0, 2)
  local r = col.r
  local g = col.g
  local b = col.b
  local a = col.a
  local wedge_radians = pi * 2 / segCount
  local a0sin = sin(0)
  local a0cos = cos(0)
  local ang
  local a1cos, a1sin
  local p00x, p00y, p11x, p11y, p10x, p10y
  mesh_Begin(MATERIAL_TRIANGLES, (segCount - math.floor(segCount / gap_modNo) + 1) * 2)
  for i = 1, segCount + 1 do
    ang = i * wedge_radians
    a1cos = cos(ang)
    a1sin = sin(ang)
    if i % gap_modNo ~= 0 then
      p00x = a0cos * r1
      p00y = a0sin * r1
      local p01x = a0cos * r2
      local p01y = a0sin * r2
      p11x = a1cos * r1
      p11y = a1sin * r1
      p10x = a1cos * r2
      p10y = a1sin * r2
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p10x, p10y, 0))
      mesh_AdvanceVertex()
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p01x, p01y, 0))
      mesh_AdvanceVertex()
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p00x, p00y, 0))
      mesh_AdvanceVertex()
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p00x, p00y, 0))
      mesh_AdvanceVertex()
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p11x, p11y, 0))
      mesh_AdvanceVertex()
      mesh_Color(r, g, b, a)
      mesh_Normal(normal_up)
      mesh_Position(Vector(p10x, p10y, 0))
      mesh_AdvanceVertex()
    end
    a0sin = a1sin
    a0cos = a1cos
  end
  return mesh_End()
end
nlr.drawWarning3d = function(center, radius, draw_fn)
  local myPos = LocalPlayer():EyePos()
  local vecDir = myPos - center
  vecDir.z = 0
  vecDir:Normalize()
  local vecAngle = vecDir:Angle()
  vecAngle:RotateAroundAxis(vecAngle:Up(), 180)
  vecAngle:RotateAroundAxis(vecAngle:Right(), 90)
  vecAngle:RotateAroundAxis(vecAngle:Up(), -90)
  cam.Start3D2D(Vector(center.x, center.y, myPos.z) + vecDir * radius, vecAngle, 0.2)
  draw_fn()
  return cam.End3D2D()
end
