nlr.uid = function()
  return lvldb and lvldb.UID() or tostring({ }):sub(10)
end
nlr.hash = function(val)
  return lvldb and lvldb.mhash(val) or string.format('%X', util.CRC(32))
end
if SERVER then
  util.AddNetworkString('nlr.notify')
  nlr.notify = function(pl, ...)
    net.Start('nlr.notify')
    net.WriteTable({
      ...
    })
    return net.Send(pl)
  end
  nlr.notify_admins = function(...)
    net.Start('nlr.notify')
    net.WriteTable({
      ...
    })
    return net.Send(nlr.filter(player.GetAll(), nlr.isAdmin))
  end
elseif CLIENT then
  net.Receive('nlr.notify', function()
    return chat.AddText(unpack(net.ReadTable()))
  end)
end
nlr.filter = function(tbl, func)
  local ir, iw = 1, 1
  local v
  while tbl[ir] do
    v = tbl[ir]
    if func(v) then
      tbl[iw] = v
      iw = iw + 1
    end
    ir = ir + 1
  end
  for i = iw, ir do
    tbl[i] = nil
  end
  return tbl
end
nlr.formatTime = function(time)
  local seconds = math.ceil(time % 60)
  local minutes = math.floor(time / 60)
  return minutes .. 'м ' .. seconds .. 'с'
end
local sqrt = math.sqrt
nlr.dist2d = function(v1, v2)
  local dx = v1.x - v2.x
  local dy = v1.y - v2.y
  return sqrt(dx * dx + dy * dy)
end
