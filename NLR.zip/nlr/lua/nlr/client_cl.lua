local fade_distance, zone_radius, zone_fillColor_default, zone_fillColor_violated, zone_outlineColor_default
do
  local _obj_0 = nlr.cfg
  fade_distance, zone_radius, zone_fillColor_default, zone_fillColor_violated, zone_outlineColor_default = _obj_0.fade_distance, _obj_0.zone_radius, _obj_0.zone_fillColor_default, _obj_0.zone_fillColor_violated, _obj_0.zone_outlineColor_default
end
local zone_fcolor_d_r, zone_fcolor_d_g, zone_fcolor_d_b, zone_fcolor_d_a
zone_fcolor_d_r, zone_fcolor_d_g, zone_fcolor_d_b, zone_fcolor_d_a = zone_fillColor_default.r, zone_fillColor_default.g, zone_fillColor_default.b, zone_fillColor_default.a
local zone_fcolor_v_r, zone_fcolor_v_g, zone_fcolor_v_b, zone_fcolor_v_a
zone_fcolor_v_r, zone_fcolor_v_g, zone_fcolor_v_b, zone_fcolor_v_a = zone_fillColor_violated.r, zone_fillColor_violated.g, zone_fillColor_violated.b, zone_fillColor_violated.a
local zone_ocolor_r, zone_ocolor_g, zone_ocolor_b, zone_ocolor_a
zone_ocolor_r, zone_ocolor_g, zone_ocolor_b, zone_ocolor_a = zone_outlineColor_default.r, zone_outlineColor_default.g, zone_outlineColor_default.b, zone_outlineColor_default.a
local nlrzones = { }
local Zone
do
  local _base_0 = {
    draw3d = function(self)
      local pl = self.pl
      local myPos = LocalPlayer():GetPos()
      if CurTime() > self.endTime or not IsValid(self.pl) then
        self:remove()
        return 
      end
      local distance = myPos:Distance(self.pos)
      local frac = 1 - math.Clamp((distance - zone_radius) / (fade_distance - zone_radius), 0, 1)
      if frac == 0 then
        return 
      end
      local alpha = frac * 255 * 0.8
      local m = Matrix()
      m:SetTranslation(self.pos)
      cam.PushModelMatrix(m)
      render.SetMaterial(nlr.meshMaterial)
      if self.isMe then
        local fill_color = distance < zone_radius and {
          r = zone_fcolor_v_r,
          g = zone_fcolor_v_g,
          b = zone_fcolor_v_b,
          a = frac * zone_fcolor_v_a
        } or {
          r = zone_fcolor_d_r,
          g = zone_fcolor_d_g,
          b = zone_fcolor_d_b,
          a = frac * zone_fcolor_d_a
        }
        nlr.drawCircle3d_filled(zone_radius, 72, fill_color)
        nlr.drawCircle3d(zone_radius - 6, zone_radius, 72, 3, {
          r = zone_ocolor_r,
          g = zone_ocolor_g,
          b = zone_ocolor_b,
          a = frac * zone_ocolor_a
        })
        nlr.drawWarning3d(self.pos, zone_radius, function()
          return draw.DrawText('ПРЕДУПРЕЖДЕНИЕ\n	у вас в этом месте NLR зона!\n	пожалуйста подождите ' .. nlr.formatTime(self.endTime - CurTime()), 'nlr_warning_font', 0, 0, {
            r = 50,
            g = 0,
            b = 0,
            a = frac * 255
          }, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end)
      else
        local dist = (IsValid(pl) and pl:Alive() and pl:GetPos():Distance(self.pos)) or math.huge
        local violated = dist <= zone_radius
        if violated then
          nlr.drawCircle3d(zone_radius - 6, zone_radius, 72, 3, {
            r = 255,
            g = 0,
            b = 0,
            a = alpha
          })
        else
          nlr.drawCircle3d(zone_radius - 6, zone_radius, 72, 3, {
            r = 0,
            g = 255,
            b = 0,
            a = alpha * 0.2
          })
        end
        if distance < zone_radius then
          local ang = (myPos - self.pos):Angle()
          ang:RotateAroundAxis(ang:Right(), -90)
          ang:RotateAroundAxis(ang:Up(), 90)
          ang.r = 90
          ang.p = 0
          cam.Start3D2D(self.pos + Vector(0, 0, 40), ang, 0.1)
          draw.SimpleText(pl:Name() .. ' Тут умер', 'nlr_warning_font-outlined', 0, 0, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
          if violated then
            draw.SimpleText('[ОН ЗАШЕЛ В NLR ЗОНУ]', 'nlr_warning_font-outlined', 0, 80, {
              r = 255,
              g = 0,
              b = 0,
              a = 255
            }, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
          end
          cam.End3D2D()
        end
      end
      return cam.PopModelMatrix()
    end,
    draw2d = function(self)
      if self.isMe and self.pl:Alive() then
        local dist = self.pl:GetPos():Distance(self.pos)
        if dist < zone_radius then
          if self.punishTime == nil then
            self.punishTime = CurTime() + nlr.cfg.punish_delay
          end
          surface.SetDrawColor(0, 0, 0, 240)
          surface.DrawRect(ScrW() * 0.4, ScrH() * 0.425, ScrW() * 0.2, ScrH() * 0.15)
          draw.SimpleText('Уйдите из этой зоны', 'nlr_warning_font-screen', ScrW() * 0.5, ScrH() * 0.47, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
          draw.SimpleText('Покиньте зону через ' .. math.ceil(self.punishTime - CurTime()) .. '', 'nlr_warning_font-screen', ScrW() * 0.5, ScrH() * 0.53, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
          if nlr.cfg.strip_weapons_in_zone then
            for i = 0, 2 do
              local vm = self.pl:GetViewModel(i)
              if IsValid(vm) then
                vm:SetMaterial("engine/occlusionproxy")
              end
            end
          end
        else
          self.punishTime = nil
          if nlr.cfg.strip_weapons_in_zone then
            for i = 0, 2 do
              local vm = self.pl:GetViewModel(i)
              if IsValid(vm) then
                vm:SetMaterial("")
              end
            end
          end
        end
      end
    end,
    remove = function(self)
      for k, v in ipairs(nlrzones) do
        if v == self then
          table.remove(nlrzones, k)
          break
        end
      end
    end
  }
  _base_0.__index = _base_0
  local _class_0 = setmetatable({
    __init = function(self, pl, killer, pos)
      local tr = util.TraceLine({
        start = pos,
        endpos = pos - Vector(0, 0, 10000),
        mask = MASK_NPCWORLDSTATIC
      })
      self.pos = tr.HitPos
      print(pos)
      self.endTime = CurTime() + nlr.cfg.zone_cooldown
      self.pl = pl
      self.killer = killer
      self.isMe = pl == LocalPlayer()
      for k, v in ipairs(nlrzones) do
        if v.pl == pl then
          v:remove()
        end
      end
      return table.insert(nlrzones, self)
    end,
    __base = _base_0,
    __name = "Zone"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  _base_0.__class = _class_0
  Zone = _class_0
end
net.Receive('nlr.killEvent', function()
  print('received kill event')
  local pl = net.ReadEntity()
  local killer = net.ReadEntity()
  local pos = net.ReadVector()
  return Zone(pl, killer, pos)
end)
net.Receive('nlr.RemoveZone', function()
  local pl = net.ReadEntity()
  for k, v in ipairs(nlrzones) do
    if v.pl == pl then
      v:remove()
      break
    end
  end
end)
hook.Add('PostDrawTranslucentRenderables', 'nlr DrawZones', function(self)
  for k, v in ipairs(nlrzones) do
    v:draw3d()
  end
end)
return hook.Add('HUDPaint', 'nlr DrawHUD', function(self)
  for k, v in ipairs(nlrzones) do
    v:draw2d()
  end
end)
