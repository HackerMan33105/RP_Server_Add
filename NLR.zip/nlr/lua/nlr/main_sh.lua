nlr = nlr or { }
nlr.include_sv = SERVER and include or function() end
nlr.include_cl = CLIENT and include or AddCSLuaFile
nlr.include_sh = function(_p)
  nlr.include_sv(_p)
  return nlr.include_cl(_p)
end
nlr.include_sh('_config_sh.lua')
nlr.include_sh('util_sh.lua')
nlr.include_sv('punishments_sv.lua')
nlr.include_sv('server_sv.lua')
nlr.include_cl('graphics_cl.lua')
nlr.include_cl('client_cl.lua')
nlr.include_sv('x_darkrp_sv.lua')
return nlr.include_sv('x_plogs_sv.lua')
